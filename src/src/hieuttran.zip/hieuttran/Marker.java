package hieuttran;

public enum Marker {
	GYM, RESIDENCE_HALL, CLASSROOM
}